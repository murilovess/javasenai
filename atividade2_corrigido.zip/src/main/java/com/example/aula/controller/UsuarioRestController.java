package com.example.aula.controller;

import com.example.aula.dto.UsuarioCreateDTO;
import com.example.aula.dto.UsuarioDTO;
import com.example.aula.model.UsuarioModel;
import com.example.aula.service.UsuarioService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.net.URI;
import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/usuarios")
public class UsuarioRestController {

    private final UsuarioService usuarioService;

    public UsuarioRestController(UsuarioService usuarioService) {
        this.usuarioService = usuarioService;
    }

    @GetMapping
    public List<UsuarioDTO> listar() {
        return usuarioService.listarTodos().stream()
                .map(u -> new UsuarioDTO(u.getId(), u.getNome(), u.getEmail(), u.getCriadoEm()))
                .collect(Collectors.toList());
    }

    @GetMapping("/{id}")
    public ResponseEntity<UsuarioDTO> buscar(@PathVariable Long id) {
        return usuarioService.buscarPorId(id)
                .map(u -> ResponseEntity.ok(new UsuarioDTO(u.getId(), u.getNome(), u.getEmail(), u.getCriadoEm())))
                .orElse(ResponseEntity.notFound().build());
    }

    @PostMapping
    public ResponseEntity<UsuarioDTO> criar(@RequestBody UsuarioCreateDTO dto) {
        UsuarioModel criado = usuarioService.criar(dto);
        UsuarioDTO out = new UsuarioDTO(criado.getId(), criado.getNome(), criado.getEmail(), criado.getCriadoEm());
        return ResponseEntity.created(URI.create("/api/usuarios/" + criado.getId())).body(out);
    }

    @PutMapping("/{id}")
    public ResponseEntity<UsuarioDTO> atualizar(@PathVariable Long id, @RequestBody UsuarioCreateDTO dto) {
        try {
            UsuarioModel atualizado = usuarioService.atualizar(id, dto);
            UsuarioDTO out = new UsuarioDTO(atualizado.getId(), atualizado.getNome(), atualizado.getEmail(), atualizado.getCriadoEm());
            return ResponseEntity.ok(out);
        } catch (IllegalArgumentException e) {
            return ResponseEntity.notFound().build();
        }
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deletar(@PathVariable Long id) {
        try {
            usuarioService.deletar(id);
            return ResponseEntity.noContent().build();
        } catch (IllegalArgumentException e) {
            return ResponseEntity.notFound().build();
        }
    }
}
