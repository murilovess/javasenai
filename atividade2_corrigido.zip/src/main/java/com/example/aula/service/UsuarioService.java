package com.example.aula.service;

import com.example.aula.dto.UsuarioCreateDTO;
import com.example.aula.model.UsuarioModel;
import com.example.repository.UsuarioRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;

@Service
public class UsuarioService {

    private final UsuarioRepository usuarioRepository;

    public UsuarioService(UsuarioRepository usuarioRepository) {
        this.usuarioRepository = usuarioRepository;
    }

    public List<UsuarioModel> listarTodos() {
        return usuarioRepository.findAll();
    }

    public Optional<UsuarioModel> buscarPorId(Long id) {
        return usuarioRepository.findById(id);
    }

    @Transactional
    public UsuarioModel criar(UsuarioCreateDTO dto) {
        // validações simples
        if (dto.getNome() == null || dto.getNome().isBlank()) {
            throw new IllegalArgumentException("Nome é obrigatório");
        }
        if (dto.getEmail() == null || dto.getEmail().isBlank()) {
            throw new IllegalArgumentException("Email é obrigatório");
        }
        if (usuarioRepository.findByEmail(dto.getEmail()).isPresent()) {
            throw new IllegalArgumentException("Email já cadastrado");
        }
        UsuarioModel u = new UsuarioModel(dto.getNome(), dto.getEmail());
        return usuarioRepository.save(u);
    }

    @Transactional
    public UsuarioModel atualizar(Long id, UsuarioCreateDTO dto) {
        UsuarioModel u = usuarioRepository.findById(id).orElseThrow(() -> new IllegalArgumentException("Usuário não encontrado"));
        if (dto.getNome() != null && !dto.getNome().isBlank()) {
            u.setNome(dto.getNome());
        }
        if (dto.getEmail() != null && !dto.getEmail().isBlank()) {
            // checa duplicidade
            usuarioRepository.findByEmail(dto.getEmail()).ifPresent(existing -> {
                if (!existing.getId().equals(id)) {
                    throw new IllegalArgumentException("Email já cadastrado por outro usuário");
                }
            });
            u.setEmail(dto.getEmail());
        }
        return usuarioRepository.save(u);
    }

    @Transactional
    public void deletar(Long id) {
        if (!usuarioRepository.existsById(id)) {
            throw new IllegalArgumentException("Usuário não encontrado");
        }
        usuarioRepository.deleteById(id);
    }
}
