package com.example.aula.controller;

import com.example.repository.UsuarioRepository;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class UsuarioWebController {

    private final UsuarioRepository usuarioRepository;

    public UsuarioWebController(UsuarioRepository usuarioRepository) {
        this.usuarioRepository = usuarioRepository;
    }

    @GetMapping("/")
    public String index(Model model) {
        model.addAttribute("usuarios", usuarioRepository.findAll());
        return "index";
    }
}
